﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntitySpawner : MonoBehaviour
{
    public GameObject spawnedEntity;
    public float spawnTime, maxEntities;
    private float nextSpawnTime;

    private void Update()
    {
        if (nextSpawnTime <= 0 && transform.childCount < maxEntities)
        {
            SpawnEnemy();
        }
        else nextSpawnTime -= Time.deltaTime;
    }

    void SpawnEnemy()
    {
        Instantiate(spawnedEntity, transform);
        nextSpawnTime = spawnTime;
    }
}
