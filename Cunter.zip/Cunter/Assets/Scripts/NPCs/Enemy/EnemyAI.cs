﻿using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    private enum State
    {
        Roaming,
        Chasing,
        Attacking,
        GoingBackToStart,
    }

    private enum CombatClass
    {
        Melee,
        Ranged,
    }

    private State state;
    private CombatClass combatClass;

    private Vector3 startingPosition;
    private Vector3 roamPosition;

    private AIMove movement;
    public AILook looking;
    private Combat attack;
    private Quaternion initialRotation;

    private float currentHealth; 
    public float maxHealth, armor;
    public Vector3 weaponStats;
    Transform player;

    float onDeathDisappearTime = 10;

    private void Awake()
    {
        movement = GetComponent<AIMove>();
        state = State.Roaming;
        initialRotation = Quaternion.Euler(transform.localRotation.x, transform.localRotation.y, transform.localRotation.z);
        if (GetComponent<Melee>() != null)
        {
            attack = GetComponent<Melee>();
            combatClass = CombatClass.Melee;
        }
        else if (GetComponent<Ranged>() != null)
        {
            attack = GetComponent<Ranged>();
            combatClass = CombatClass.Ranged;
        } else
        {
            Debug.Log("Enemy " + transform.name + " spawned with no combat class. Did you retard forget something?");
        }
        attack.isEnemy = true;
        attack.NewWeapon(weaponStats);
        attack.enemyLayers = LayerMask.GetMask("Player");
    }

    void Start()
    {
        player = PlayerManager.instance.player.transform;
        startingPosition = transform.position;
        roamPosition = GetRoamingPosition();
        currentHealth = maxHealth;
    }

 
    void Update()
    {
        float attackRange = attack.attackRange;
        float reachedPositionDistance = 1f;
        switch (state) 
        {
            case State.Roaming:
                movement.move(roamPosition, 4);

                if (Vector3.Distance(transform.position, roamPosition) < reachedPositionDistance)
                {
                    //Position reached
                    roamPosition = GetRoamingPosition();
                }

                FindTarget();   
                break;
            case State.Chasing:
                movement.move(player.position, 8);

                looking.LookToPlayer(player.position, initialRotation.x, initialRotation.z);
                if (combatClass == CombatClass.Ranged)
                    looking.MoveAimAssist(attack.attackPoint.transform, player.position);
                if (Vector3.Distance(transform.position, player.position) < attackRange)
                {
                    state = State.Attacking;  
                }

                float stopChasingDistance = 20f;
                if (Vector3.Distance(transform.position, player.position) > stopChasingDistance)
                {
                    //Too far, it's time to stop
                    state = State.GoingBackToStart;
                }
                break;
            case State.Attacking:
                if (!attack.onCooldown)
                    attack.Attack();
                if (Vector3.Distance(transform.position, player.position) > attackRange)
                {
                    state = State.Chasing;
                }

                if (combatClass == CombatClass.Ranged)
                {
                    looking.UpdateLooking(attackRange, player.position, initialRotation.x, initialRotation.z, attack.attackPoint);
                }
                break;
            case State.GoingBackToStart:
                movement.move(startingPosition, 8);
                if (Vector3.Distance(transform.position, startingPosition) < reachedPositionDistance)
                {
                    state = State.Roaming;
                }
                break;
        }
    }

    private Vector3 GetRoamingPosition()
    {
        return startingPosition + new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized * Random.Range(5, 10);
    }

    private void FindTarget()
    {
        float targetRange = 10f;
        if (Vector3.Distance(transform.position, player.position) < targetRange)
        {
            //Player nearby
            state = State.Chasing;
        }
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Ze enemy fucking died.");
        GetComponent<CharacterController>().enabled = false;
        GetComponent<EnemyAI>().enabled = false;
        enabled = false;
        Invoke("DeleteDeadEnemy", onDeathDisappearTime);
    }

    void DeleteDeadEnemy()
    {
        Destroy(gameObject);
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(startingPosition, 5);
        Gizmos.DrawWireSphere(startingPosition, 10);
        Gizmos.DrawWireSphere(transform.position, 10);
        Gizmos.DrawWireSphere(transform.position, 3);
    }
}
