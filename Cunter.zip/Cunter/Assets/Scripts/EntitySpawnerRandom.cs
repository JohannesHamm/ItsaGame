﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntitySpawnerRandom : MonoBehaviour
{
    public GameObject spawnedEntity;
    public float spawnTime, maxEntities, area;
    private float nextSpawnTime;

    private void Update()
    {
        if (nextSpawnTime <= 0 && transform.childCount < maxEntities)
        {
            SpawnEnemy();
        }
        else nextSpawnTime -= Time.deltaTime;
    }

    void SpawnEnemy()
    {
        Instantiate(spawnedEntity, new Vector3(Random.Range(transform.position.x-area, transform.position.x + area),0, Random.Range(transform.position.z - area, transform.position.z + area)), transform.rotation, transform);
        nextSpawnTime = spawnTime;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position, new Vector3(area, 1, area));
    }
}
