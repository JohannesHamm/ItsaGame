﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puzzle : MonoBehaviour
{
    void Update()
    {
        if (transform.childCount == 0)
        {
            //Do stuff
        }

    }
}
