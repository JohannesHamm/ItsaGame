﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EquipmentSlotController : MonoBehaviour
{

    public Text displayText;
    public EquipableItem equipableItem;

    private void Start()
    {
        UpdateInfoEquipable();
    }

    public void UpdateInfoEquipable()
    {
        displayText = transform.Find("Text").GetComponent<Text>();
        Image displayImage = transform.Find("Image").GetComponent<Image>();

        if (equipableItem)
        {
            displayText.text = equipableItem.itemName;
            displayImage.sprite = equipableItem.icon;
            displayImage.color = Color.white;
        }
        else
        {
            displayText.text = "";
            displayImage.sprite = null;
            //displayImage.color = Color.clear; //das teil hier macht Fehlermeldunge, wir brauchen es aber nicht
        }
    }

    public void UseEquipable()
    {
        if (equipableItem)
         equipableItem.Use();
        
    }

    public void Unequip()
    {
        //if (equipableItem)
        // equipableItem.Unequip();
        

    }
}