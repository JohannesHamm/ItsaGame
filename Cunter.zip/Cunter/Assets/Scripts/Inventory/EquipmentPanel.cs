﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquipmentPanel : MonoBehaviour
{
    public GameObject player;
    public GameObject inventoryPanel;
    public static EquipmentPanel instance;

    public List<EquipableItem> list = new List<EquipableItem>();

    void updateEquipmentPanelSlots()
    {
        int index = 0;
        foreach (Transform child in inventoryPanel.transform)
        {
            EquipmentSlotController slot = child.GetComponent<EquipmentSlotController>();

            if (index < list.Count)
            {
                slot.equipableItem = list[index];
            }
            else
            {
                slot.equipableItem = null;
            }

            slot.UpdateInfoEquipable();
            index++;
        }
    }

    void Start()
    {
        instance = this;
        updateEquipmentPanelSlots();

        while (list.Count < 5)
        {
            list.Add(null);
        }
    }

    void Update()
    {
        
    }

    public void AddEquipable(int index,EquipableItem equipableItem)
    {
        
        list.Insert(index,equipableItem);
        
        updateEquipmentPanelSlots();
    }
    public void RemoveEquipable(EquipableItem equipableItem)
    {
        list.Insert(list.IndexOf(equipableItem), null);
        updateEquipmentPanelSlots();
    }
}
