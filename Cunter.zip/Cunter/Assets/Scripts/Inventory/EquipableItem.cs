﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "new Equipable", menuName = "Items/Equipable")]
public class EquipableItem : Item
{
    public Equipment equipment;
    public int armor = 0;
    public enum Equipment
    {
        Helmet,
        Chestplate,
        Legs,
        Boots,
        WeaponMelee,
        WeaponRanged,
        Debug,
    }


    public override void Use()
    {
        GameObject player = PlayerManager.instance.player;
        PlayerStats playerHealth = player.GetComponent<PlayerStats>();
        switch (equipment)
        {
            case Equipment.Helmet:
                EquipmentPanel.instance.AddEquipable(0,this);
                break;
            case Equipment.Chestplate:
                EquipmentPanel.instance.AddEquipable(1,this);
                break;
            case Equipment.Legs:
                EquipmentPanel.instance.AddEquipable(2,this);
                break;
            case Equipment.Boots:
                EquipmentPanel.instance.AddEquipable(3,this);
                break;
            case Equipment.WeaponMelee:
                EquipmentPanel.instance.AddEquipable(4,this);
                break;
            case Equipment.WeaponRanged:
                //EquipmentPanel.instance.AddEquipable(,this);
                break;
            case Equipment.Debug:
                EquipmentPanel.instance.AddEquipable(4,this);
                break;
        }

        Inventory.instance.Remove(this);
    }

    public void Unequip(int position)
    {
        //EquipmentPanel.instance.list.Insert(position, null);
        //updateEquipmentPanelSlots();
    }

}