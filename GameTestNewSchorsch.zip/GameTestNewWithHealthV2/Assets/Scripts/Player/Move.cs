﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public CharacterController controller;
    public Transform groundCheck, screenMid, target;
    public Camera cam;
    Interactable focus;
    Pickup focusInstant;

    public float speed = 12f;
    public float gravity = -9.81f;
    public float groundDistance = 0.4f;
    public float jumpHeight = 2f;
    public LayerMask groundMask;
    public bool isGrounded;
    Vector3 velocity;


    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        if(isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        if(Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * z;

        if (Input.GetKeyDown(KeyCode.LeftShift))
            speed = 18;
        if (Input.GetKeyUp(KeyCode.LeftShift))
            speed = 12;
        controller.Move(move * speed * Time.deltaTime);
        controller.Move(velocity * Time.deltaTime);

        velocity.y += gravity * Time.deltaTime;

        Ray ray = cam.ScreenPointToRay(screenMid.position);
        if (Physics.Raycast(ray, out RaycastHit hit, 100))
        {
            Pickup pickupable = hit.collider.GetComponent<Pickup>();
            if (pickupable != null)
            {
                focusInstant = pickupable;
                focusInstant.OnFocused(transform);
            }
            Interactable interactable = hit.collider.GetComponent<Interactable>();
            if (Input.GetKeyDown(KeyCode.F) && interactable != null)
            {
                focus = interactable;
                target = focus.transform;
                focus.OnFocused(transform);
            }
        } else if (focus != null)
        {
            target = null;
            focus.OnDeFocused();
            focus = null;
        }
       
       
            
    }

    
}
