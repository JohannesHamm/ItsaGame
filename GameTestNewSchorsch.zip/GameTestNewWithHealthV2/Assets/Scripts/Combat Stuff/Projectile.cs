﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed, lifeTime, distance, damage;
    CharacterController thisObject;


    private void Start()
    {
        thisObject = GetComponent<CharacterController>();
        Invoke("DestroyProjectile", lifeTime);
    }
    private void Update()
    {
        Vector3 move = transform.up * speed * Time.deltaTime;
        thisObject.Move(move);
        if (Physics.Raycast(transform.position, transform.up, out RaycastHit hit, distance))
        {
            EnemyAI enemy = hit.collider.GetComponent<EnemyAI>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
                Destroy(gameObject);
            }
        }
    }

    void DestroyProjectile()
    {
        Destroy(gameObject);
    }
}
