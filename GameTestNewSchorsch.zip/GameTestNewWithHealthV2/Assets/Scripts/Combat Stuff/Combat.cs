﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Combat : MonoBehaviour
{
    public float attackRate; //seconds between attacks
    protected float nextAttackTime = 0f; //how much time until the next attack
    public LayerMask enemyLayers; //enemies to be attacked
    public bool onCooldown = false, isEnemy = false;
    public Transform attackPoint;
}
