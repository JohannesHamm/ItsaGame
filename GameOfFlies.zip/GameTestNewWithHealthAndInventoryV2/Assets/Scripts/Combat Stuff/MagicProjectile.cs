﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagicProjectile : MonoBehaviour
{
    public float speed, lifeTime, initialRange, maxRange, damage, secondsBeforeGravityEffect;
    private float currentRange;
    CharacterController thisObject;
    LayerMask hostileLayers;
    public bool isEnemy = false, exploding = false;
    private Vector3 velocity;
    private float gravity = 9.81f;

    private void Start()
    {
        currentRange = 1;
        secondsBeforeGravityEffect *= 16;
        thisObject = GetComponent<CharacterController>();
        if (!isEnemy)
            hostileLayers = LayerMask.GetMask("Enemy");
        else
            hostileLayers = LayerMask.GetMask("Player");
    }

    private void Update()
    {
        if (!exploding)
        {
            Vector3 move = transform.up * speed * Time.deltaTime;
            thisObject.Move(move);
            if (secondsBeforeGravityEffect <= 0)
            {
                velocity.y -= gravity * Time.deltaTime;
                thisObject.Move(velocity * Time.deltaTime);
            }
        }
        

        if (!isEnemy && !exploding)
        {
            Collider[] hitEnemies = Physics.OverlapSphere(transform.position, initialRange, hostileLayers);
            foreach (Collider enemy in hitEnemies)
            {
                if (enemy.GetComponent<EnemyAI>() != null && enemy.GetComponent<EnemyAI>().enabled == true)
                {
                    enemy.GetComponent<EnemyAI>().TakeDamage(damage);
                    Debug.Log("We hit " + enemy.name);
                    Explode();
                }
            }
        }
        if (isEnemy && !exploding)
        {
            Collider[] hitPlayers = Physics.OverlapSphere(transform.position, initialRange, hostileLayers);
            foreach (Collider player in hitPlayers)
            {
                if (player.GetComponent<PlayerStats>().enabled == true)
                {
                    player.GetComponent<PlayerStats>().TakeDamage(damage);
                    Debug.Log("We got hit by an arrow!");
                    Explode();
                }
            }
        }

        if (lifeTime <= 0 || exploding == true)
        {
            Explode();
        }

        if (secondsBeforeGravityEffect > 0)
            secondsBeforeGravityEffect -= 1;
        lifeTime -= Time.deltaTime;
    }

    void Explode()
    {
        Mathf.Clamp(initialRange, 0, 1);
        exploding = true;
        GetComponent<SphereCollider>().enabled = false;
        thisObject.enabled = false;
        if (currentRange <= maxRange)
        {
            currentRange *= 1.1f;
            transform.localScale *= 1.1f;
        }

        if (!isEnemy)
        {
            Collider[] hitEnemies = Physics.OverlapSphere(transform.position, currentRange * initialRange, hostileLayers);
            foreach (Collider enemy in hitEnemies)
            {
                if (enemy.GetComponent<EnemyAI>() != null && enemy.GetComponent<EnemyAI>().enabled == true)
                {
                    enemy.GetComponent<EnemyAI>().TakeDamage(damage*2);
                    Debug.Log("We hit " + enemy.name + " with an explosion");
                }
            }
        }
        if (isEnemy)
        {
            Collider[] hitPlayers = Physics.OverlapSphere(transform.position, currentRange * initialRange, hostileLayers);
            foreach (Collider player in hitPlayers)
            {
                if (player.GetComponent<PlayerStats>().enabled == true)
                {
                    player.GetComponent<PlayerStats>().TakeDamage(damage);
                    Debug.Log("We got hit by an arrow!");
                }
            }
        }

        if (currentRange > maxRange)
            DestroyProjectile();
    }

    void DestroyProjectile()
    {
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, initialRange);
    }
}
