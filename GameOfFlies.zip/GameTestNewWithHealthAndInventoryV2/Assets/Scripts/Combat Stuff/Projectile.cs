﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed, lifeTime, range, damage;
    CharacterController thisObject;
    LayerMask hostileLayers;
    public bool isEnemy = false;

    private void Start()
    {
        thisObject = GetComponent<CharacterController>();
        Invoke("DestroyProjectile", lifeTime);
        if (!isEnemy)
            hostileLayers = LayerMask.GetMask("Enemy");
        else
            hostileLayers = LayerMask.GetMask("Player");
    }

    private void Update()
    {
        Vector3 move = transform.up * speed * Time.deltaTime;
        thisObject.Move(move);
        if (!isEnemy)
        {
            Collider[] hitEnemies = Physics.OverlapSphere(transform.position, range, hostileLayers);
            foreach (Collider enemy in hitEnemies)
            {
                if (enemy.GetComponent<EnemyAI>() != null && enemy.GetComponent<EnemyAI>().enabled == true)
                {
                    enemy.GetComponent<EnemyAI>().TakeDamage(damage);
                    Debug.Log("We hit " + enemy.name);
                    DestroyProjectile();
                }
            }
        }
        if (isEnemy)
        {
            Collider[] hitPlayers = Physics.OverlapSphere(transform.position, range, hostileLayers);
            foreach (Collider player in hitPlayers)
            {
                if (player.GetComponent<PlayerStats>().enabled == true)
                {
                    player.GetComponent<PlayerStats>().TakeDamage(damage);
                    Debug.Log("We got hit by an arrow!");
                    DestroyProjectile();
                }
            }
        }
    }

    void DestroyProjectile()
    {
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, range);
    }
}
