﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AILook : MonoBehaviour
{
    public void LookToPlayer(Vector3 target, float initialX, float initialZ)
    {
        // Rotate the camera every frame so it keeps looking at the target
        transform.LookAt(target);

        //keep existing "y" rotation and set "x" and "z" rotation from intitalRotation
        transform.localRotation = Quaternion.Euler(new Vector3(initialX, transform.localRotation.eulerAngles.y, initialZ));

    }

    public void MoveAimAssist(Transform AimAssist, Vector3 target)
    {
        AimAssist.LookAt(target);
    }

    public void UpdateLooking(float attackRange, Vector3 target, float initialX, float initialZ, Transform AimAssist) 
    {
        if (Physics.Raycast(transform.position, transform.up, out RaycastHit hit, attackRange * 10))
        {
            Transform player = hit.collider.transform;
            if (player == null)
            {
                LookToPlayer(target, initialX, initialZ);
                MoveAimAssist(AimAssist, target);
            }
        }
    }
}
