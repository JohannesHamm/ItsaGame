﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIMove : MonoBehaviour
{
    private float gravity = -9.81f;

    private float groundDistance = 0.29f;
    private float x, z;

    private CharacterController thisMob;
    public Transform groundCheck;

    public LayerMask groundMask;
    public bool isGrounded;
    Vector3 velocity;

    private void Awake()
    {
        thisMob = GetComponent<CharacterController>();
    }

    public void move(Vector3 target, float speed)
    {
        float distance = Vector3.Distance(target, transform.position);
        if (transform.position.x < target.x)
            x = 1;
        if (transform.position.x > target.x)
            x = -1;
        if (transform.position.x == target.x)
            x = 0;
        if (transform.position.z < target.z)
            z = 1;
        if (transform.position.z > target.z)
            z = -1;
        if (transform.position.z == target.z)
            z = 0;
        Vector3 move = transform.right * x + transform.forward * z;
        thisMob.Move(move * speed * Time.deltaTime);

        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        velocity.y += gravity * Time.deltaTime;
        thisMob.Move(velocity * Time.deltaTime);

    }
}
