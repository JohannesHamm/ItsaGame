﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "new Equipable", menuName = "Items/Equipable")]
public class EquipableItem : Item
{
    public Equipment equipment;
    public int armor = 0;
    public enum Equipment
    {
        Helmet,
        Chestplate,
        Legs,
        Boots,
        WeaponMelee,
        WeaponRanged,
    }

    public override void Use()
    {
        GameObject player = PlayerManager.instance.player;
        PlayerStats playerHealth = player.GetComponent<PlayerStats>();
        switch (equipment)
        {
            case Equipment.Helmet:
                
                break;
            case Equipment.Chestplate:

                break;
            case Equipment.Legs:

                break;
            case Equipment.Boots:

                break;
            case Equipment.WeaponMelee:

                break;
            case Equipment.WeaponRanged:

                break;
}

        Inventory.instance.Remove(this);
    }

}