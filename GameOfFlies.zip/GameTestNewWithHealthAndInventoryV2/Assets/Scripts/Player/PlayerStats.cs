﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{
    //permanent stats
    private enum CombatClass
    {
        Melee,
        Ranged,
    }
    CombatClass combatClass;
    //semi-permanent stats
    public Stat maxHealth;
    //public Stat maxMana;
    public Stat armor;

    //dynamic stats
    public float currentHealth { get; private set; }
    //public int currentMana { get; private set; }

    //weapon stats, should probably be it's own thing
    public Vector3 weaponStats; //Format is damage, attackrate, range

    //misc.
    public UIBar healthBar;
    public Look look;
    public GameObject Inventory;
    float inventoryOpen = 0;

    private void Awake()
    {
        weaponStats = new Vector3(5, 2, 2);
        currentHealth = maxHealth.getValue();
        if (GetComponent<Melee>() != null)
        {
            GetComponent<Melee>().NewWeapon(weaponStats);
            GetComponent<Melee>().enemyLayers = LayerMask.GetMask("Enemy");
            combatClass = CombatClass.Melee;
        }
        else if (GetComponent<Ranged>() != null)
        {
            GetComponent<Ranged>().enemyLayers = LayerMask.GetMask("Enemy");
            combatClass = CombatClass.Ranged;
        }
        else
            Debug.Log("I don't know how you did this, but " + transform.name + " does not have a combatclass.");
    }

    public void TakeDamage (float damage)
    {
        damage -= armor.getValue();
        damage = Mathf.Clamp(damage, 1, int.MaxValue);
        currentHealth -= damage;
        Debug.Log("You took " + damage + " damage");

        healthBar.SetHealth(currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public virtual void Die()
    {
        Debug.Log("You died. Great job.");
        GetComponent<Move>().enabled = false;
        look.enabled = false;
        if (combatClass == CombatClass.Melee)
            GetComponent<Melee>().enabled = false;
        if (combatClass == CombatClass.Ranged)
            GetComponent<Ranged>().enabled = false;
        enabled = false;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            TakeDamage(10);
        }
        if (Input.GetKeyDown(KeyCode.U))
        {
            armor.addModifier(1);
            if (combatClass == CombatClass.Melee)
            {
                weaponStats += new Vector3(1, 0, 0);
                GetComponent<Melee>().NewWeapon(weaponStats);
            }
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            inventoryOpen += 1;
            if (inventoryOpen > 2)
                inventoryOpen = 1;
        }

        switch (inventoryOpen)
        {
            case 1:
                Inventory.SetActive(true);
                look.enabled = false;
                if (combatClass == CombatClass.Melee)
                    GetComponent<Melee>().enabled = false;
                if (combatClass == CombatClass.Ranged)
                    GetComponent<Ranged>().enabled = false;
                Cursor.lockState = CursorLockMode.None;
                break;
            case 2:
                Inventory.SetActive(false);
                look.enabled = true;
                if (combatClass == CombatClass.Melee)
                    GetComponent<Melee>().enabled = true;
                if (combatClass == CombatClass.Ranged)
                    GetComponent<Ranged>().enabled = true;
                Cursor.lockState = CursorLockMode.Locked;
                break;
        }
    }

    public void Heal(float amount)
    {
        currentHealth += amount;
        if (currentHealth > maxHealth.getValue())
            currentHealth = maxHealth.getValue();
        healthBar.SetHealth(currentHealth);
    }
}
