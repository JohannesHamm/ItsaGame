﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractMulti : Interactable
{
    public float minClicks = 0f, currentClick = 0f;
    public override void Interact()
    {
        if (currentClick < minClicks)
        {
            Debug.Log(transform.name + " says that thou shalleth fuck off already.");
        }
        else if (currentClick == minClicks)
        {
            Debug.Log(transform.name + " is getting annoyed by your pointless shenanigans.");
        }
        else if (currentClick > minClicks && currentClick < minClicks * 2)
        {
            Debug.Log(transform.name + " says: 'How does thou dare to click it's Holyness the Holy Cube? Does thou not have shame? God will hear of this.' Uh oh...");
        }
        else
        {
            Debug.Log(transform.name + " says: 'I've had enough of you! Feel God's wrath!' RUN!"); 
        }
            currentClick++;
    }
}
