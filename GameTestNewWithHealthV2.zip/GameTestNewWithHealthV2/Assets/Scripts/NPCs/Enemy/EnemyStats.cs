﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    public Stat maxHealth;
    public Stat armor;
    public Stat damage;

}
