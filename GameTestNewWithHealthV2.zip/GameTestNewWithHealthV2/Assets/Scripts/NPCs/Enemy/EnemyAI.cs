﻿using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    private enum State
    {
        Roaming,
        Chasing,
        Attacking,
        GoingBackToStart,
    }

    private State state;

    private Vector3 startingPosition;
    private Vector3 roamPosition;

    private AIMove movement;
    public AILook looking;
    private Melee attack;
    private Quaternion initialRotation;

    private float currentHealth; 
    public float maxHealth, armor;
    public Vector3 weaponStats;

    private void Awake()
    {
        movement = GetComponent<AIMove>();
        state = State.Roaming;
        initialRotation = Quaternion.Euler(transform.localRotation.x, transform.localRotation.y, transform.localRotation.z);
        attack = GetComponent<Melee>();
        attack.isEnemy = true;
        attack.NewWeapon(weaponStats);
        attack.enemyLayers = LayerMask.GetMask("Player");
    }

    void Start()
    {
        startingPosition = transform.position;
        roamPosition = GetRoamingPosition();
        currentHealth = maxHealth;
    }

 
    void Update()
    {
        float attackRange = attack.attackRange;
        float reachedPositionDistance = 1f;
        switch (state) 
        {
            case State.Roaming:
                movement.move(roamPosition, 4);

                if (Vector3.Distance(transform.position, roamPosition) < reachedPositionDistance)
                {
                    //Position reached
                    roamPosition = GetRoamingPosition();
                }

                FindTarget();   
                break;
            case State.Chasing:
                movement.move(PlayerManager.instance.player.transform.position, 8);

                looking.LookToPlayer(PlayerManager.instance.player.transform.position, initialRotation.x, initialRotation.z);
                if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) < attackRange)
                {
                    state = State.Attacking;  
                }

                float stopChasingDistance = 20f;
                if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) > stopChasingDistance)
                {
                    //Too far, it's time to stop
                    state = State.GoingBackToStart;
                }
                break;
            case State.Attacking:
                if (!attack.onCooldown)
                    attack.MeeleeAttack();
                if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) > attackRange)
                {
                    state = State.Chasing;
                }
                break;
            case State.GoingBackToStart:
                movement.move(startingPosition, 8);
                if (Vector3.Distance(transform.position, startingPosition) < reachedPositionDistance)
                {
                    state = State.Roaming;
                }
                break;
        }
    }

    private Vector3 GetRoamingPosition()
    {
        return startingPosition + new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized * Random.Range(5, 10);
    }

    private void FindTarget()
    {
        float targetRange = 10f;
        if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) < targetRange)
        {
            //Player nearby
            state = State.Chasing;
        }
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Ze enemy fucking died.");
        GetComponent<CharacterController>().enabled = false;
        GetComponent<EnemyAI>().enabled = false;
        enabled = false;
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(startingPosition, 5);
        Gizmos.DrawWireSphere(startingPosition, 10);
        Gizmos.DrawWireSphere(transform.position, 10);
        Gizmos.DrawWireSphere(transform.position, 3);
    }
}
