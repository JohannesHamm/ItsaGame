﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questgiver : Interactable
{
    public override void Interact()
    {
        Debug.Log(transform.name + " says: Hello, " + player.name + ", I have a mission for you." );
    }
}
