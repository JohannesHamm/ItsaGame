﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{
    //semi-permanent stats
    public Stat maxHealth;
    //public Stat maxMana;
    public Stat armor;

    //dynamic stats
    public float currentHealth { get; private set; }
    //public int currentMana { get; private set; }

    //weapon stats, should probably be it's own thing
    public Vector3 weaponStats; //Format is damage, attackrate, range

    //misc.
    public UIBar healthBar;
    public Look look;

    private void Awake()
    {
        weaponStats = new Vector3(5, 2, 2);
        currentHealth = maxHealth.getValue();
        GetComponent<Melee>().NewWeapon(weaponStats);
        GetComponent<Melee>().enemyLayers = LayerMask.GetMask("Enemy");
        GetComponent<Ranged>().enemyLayers = LayerMask.GetMask("Enemy");
    }

    public void TakeDamage (float damage)
    {
        damage -= armor.getValue();
        damage = Mathf.Clamp(damage, 1, int.MaxValue);
        currentHealth -= damage;
        Debug.Log("You took " + damage + " damage");

        healthBar.SetHealth(currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public virtual void Die()
    {
        Debug.Log("You died. Great job.");
        GetComponent<Move>().enabled = false;
        look.enabled = false;
        GetComponent<Melee>().enabled = false;
        enabled = false;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            TakeDamage(10);
        }
        if (Input.GetKeyDown(KeyCode.U))
        {
            armor.addModifier(1);
            weaponStats += new Vector3(1, 0, 0);
            GetComponent<Melee>().NewWeapon(weaponStats);
        }
    }
}
