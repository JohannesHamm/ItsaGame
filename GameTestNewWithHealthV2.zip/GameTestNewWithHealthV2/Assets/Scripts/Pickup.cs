﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    public float radius = 5f;
    bool isFocus;
    Transform player;

    public virtual void PickupItem()
    {
        Debug.Log(transform.name + " was picked up and is not amused.");
        Destroy(gameObject);
    }
    private void Update()
    {
        if (isFocus)
        {
            if (Vector3.Distance(player.position, transform.position) <= radius)
            {
                PickupItem();
            }
        }
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, radius);
    }

    public void OnFocused(Transform playerTransform)
    {
        isFocus = true;
        player = playerTransform;
    }

}
