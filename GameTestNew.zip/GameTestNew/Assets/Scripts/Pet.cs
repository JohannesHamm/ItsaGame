﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pet : MonoBehaviour
{
    public int petType = 0;
    float y = 3;
    public Transform player;
    public Move playerMove;
    public CharacterController pet;
    public double normalY = 5;

    void Update()
    {
        Idle();
    }

    public void Idle()
    {
        switch (petType) {
            case 0:
                break;
            case 1:
                Vector3 moveUp = transform.up * y;
                pet.Move(moveUp * Time.deltaTime);
                normalY = player.position.y + 3;
                if (transform.position.y > normalY + 1)
                    y = -1;
                else if (transform.position.y < normalY - 1)
                    y = 1;
                /*else if (transform.position.y > normalY - 1 && !(transform.position.y > normalY))
                    y = 1;
                else if (transform.position.y > normalY && !(transform.position.y > normalY + 1))
                    y = -1;*/
                break;
        }
    }
}
