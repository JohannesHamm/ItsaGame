﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public float health = 100;


    public bool damaged;
    bool weGetIt = false;

    public Move move;
    public Look look;
    public Transform spike;
    public Material healthMat;
    //public Transform healthBar;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("g") && health != 0)
        {
            health -= 10;
            damaged = true;
        }

        if (damaged)
        {
            damaged = false;
            print("You got hit");
            healthMat.SetColor( null , new Color(255 * health, 0, 0));
            /*healthBar.localScale.Set(healthBar.localScale.x / 100 * health, healthBar.localScale.y, healthBar.localScale.z);
            healthBar.localPosition.Set(healthBar.localPosition.x / 100 * health, healthBar.localPosition.y, healthBar.localPosition.z);*/
        }

        if (health == 0 && !weGetIt)
        {
            print("You are dead");
            move.speed = 0;
            move.jumpHeight = 0;
            look.enabled = false;
            weGetIt = true;
        }
    }
   
}
