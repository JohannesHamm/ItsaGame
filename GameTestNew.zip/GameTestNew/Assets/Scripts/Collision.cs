﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision : MonoBehaviour
{
    public Damage damage;
    public Transform spike;
    void OnCollisionEnter(UnityEngine.Collision collision)
    {
        if (collision.collider.CompareTag("Obstacle"))
        {
            damage.health -= 10;
            damage.damaged = true;
            spike.position.Set(spike.position.x, -5, spike.position.z);
        }
    }
}
