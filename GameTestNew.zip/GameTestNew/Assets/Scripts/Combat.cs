﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Combat : MonoBehaviour
{
    public Transform attackPoint;
    public float attackRange = 2f;
    public LayerMask enemyLayers;
    public float attackType = 0f;
    public int damage = 10;
    public float attackRate = 2f;
    private float nextAttackTime = 0f;
    void Update()
    {
        if (Time.time >= nextAttackTime)
        {
            if (Input.GetKeyDown(KeyCode.Mouse0))
            {
                switch (attackType)
                {
                    case 0: //Melee
                        MeeleeAttack();
                        nextAttackTime = Time.time + 1f / attackRate;
                        break;
                }
            }
        }
    }

    void MeeleeAttack()
    {
                Collider[] hitEnemies = Physics.OverlapSphere(attackPoint.position, attackRange, enemyLayers);
                foreach (Collider enemy in hitEnemies)
                {
                    if (enemy.GetComponent<Enemy>().enabled == true)
                    enemy.GetComponent<Enemy>().takeDamage(damage);
                }
        
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
        if (attackPoint == null)
            return;
    }
}
