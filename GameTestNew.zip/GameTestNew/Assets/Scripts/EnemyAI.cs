﻿using UnityEngine;
using UnityEngine.UIElements;

public class EnemyAI : MonoBehaviour
{

    private enum State
    {
        Roaming,
        Chasing,
    }

    private State state;

    private Vector3 startingPosition;
    private Vector3 roamPosition;

    private AIMove movement;

    private void Awake()
    {
        movement = GetComponent<AIMove>();
        state = State.Roaming;
    }

    void Start()
    {
        startingPosition = transform.position;
        roamPosition = getRoamingPosition();
    }

 
    void Update()
    {
        switch (state) 
        {
            case State.Roaming:
                movement.move(roamPosition, 4);

                float reachedPositionDistance = 1f;
                if (Vector3.Distance(transform.position, roamPosition) < reachedPositionDistance)
                {
                    //Position reached
                    roamPosition = getRoamingPosition();
                }

                findTarget();   
                break;
            case State.Chasing:
                movement.move(PlayerManager.instance.player.transform.position, 8);
                float attackRange = 3f;
                if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) < attackRange)
                {
                    //Player attackable
                }
                break;  
        }
    }

    private Vector3 getRoamingPosition()
    {
        return startingPosition + new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized * Random.Range(5, 10);
    }

    private void findTarget()
    {
        float targetRange = 10f;
        if (Vector3.Distance(transform.position, PlayerManager.instance.player.transform.position) < targetRange)
        {
            //Player nearby
            state = State.Chasing;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(startingPosition, 5);
        Gizmos.DrawWireSphere(startingPosition, 10);
        Gizmos.DrawWireSphere(transform.position, 10);
        Gizmos.DrawWireSphere(transform.position, 3);
    }
}
