﻿using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    private HealthBar healthBar;
    public Stat maxHealth;
    public Stat armor;
    //public Stat damage;
    //public Stat maxMana;
    public int currentHealth { get; private set; }
    //public int currentMana { get; private set; }

    public string currentHealthText;
    //public Text currentHealthTextUI;

    private void Awake()
    {
        healthBar = GetComponent < HealthBar >();
        currentHealth = maxHealth.getValue();
        currentHealthText = (maxHealth.getValue() + "/" + maxHealth.getValue());
        healthBar.SetMaxHealth(maxHealth.getValue());
    }

    public void TakeDamage (int damage)
    {
        damage -= armor.getValue();
        damage = Mathf.Clamp(damage, 1, int.MaxValue);
        currentHealth -= damage;
        Debug.Log("You took " + damage + " damage");

        currentHealthText = (currentHealth + "/" + maxHealth.getValue());
        //currentHealthTextUI = currentHealthText;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public virtual void Die()
    {
        Debug.Log("You died. Great job.");
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            TakeDamage(10);
        }
        healthBar.SetHealth(currentHealth);
    }
}
