﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Melee : Combat
{
    public float damage; //damage per attack, set by Stats. Ranged damage is defined by projectile
    public float attackRange = 2f; //Range of the sword etc.

    void Update()
    {
        if (nextAttackTime <= 0)
        {
            onCooldown = false;
            if (Input.GetKeyDown(KeyCode.Mouse0) && !isEnemy)
            {
                MeeleeAttack();
            }
        } else
        {
            nextAttackTime -= Time.deltaTime;
        }
    }
    public void MeeleeAttack()
    {
        //Player is attacking
        if (!isEnemy) {
            Collider[] hitEnemies = Physics.OverlapSphere(attackPoint.position, attackRange, enemyLayers);
            foreach (Collider enemy in hitEnemies)
            {
                if (enemy.GetComponent<EnemyAI>().enabled == true)
                {
                    enemy.GetComponent<EnemyAI>().TakeDamage(damage);
                    Debug.Log("We hit " + enemy.name);
                }
            }
        }
        //Player is attacked
        if (isEnemy)
        {
            Collider[] hitPlayers = Physics.OverlapSphere(attackPoint.position, attackRange, enemyLayers);
            foreach (Collider player in hitPlayers)
            {
                if (player.GetComponent<PlayerStats>().enabled == true)
                {
                    player.GetComponent<PlayerStats>().TakeDamage(damage);
                    Debug.Log("We've been hit by " + transform.name);
                }
            }
        }
        onCooldown = true;
        nextAttackTime = attackRate;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
        if (attackPoint == null)
            return;
    }

    public void NewWeapon(Vector3 newStats)
    {
        damage = newStats.x;
        attackRate = newStats.y;
        attackRange = newStats.z;
    }
}
