﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor.VersionControl;
using UnityEngine;

public class PuzzleComponent : MonoBehaviour
{
    public float radius = 5f;
    bool isFocus;
    Transform player;

    public virtual void PickupItem()
    {
        Debug.Log("Picked up " + transform.name + ". Huh, this seems strange...");
        Destroy(gameObject);
    }
    private void Update()
    {
        if (isFocus)
        {
            if (Vector3.Distance(player.position, transform.position) <= radius)
            {
                PickupItem();
            }
        }
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, radius);
    }

    public void OnFocused(Transform playerTransform)
    {
        isFocus = true;
        player = playerTransform;
    }

}
