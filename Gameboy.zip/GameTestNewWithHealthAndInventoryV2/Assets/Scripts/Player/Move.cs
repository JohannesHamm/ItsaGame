﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public CharacterController controller;
    public Transform groundCheck, screenMid, target;
    public Camera cam;
    Interactable focus;
    Pickup focusInstant;
    PuzzleComponent focusInstantB;

    public float speed = 12f, gravity = -9.81f, groundDistance = 0.4f, jumpHeight = 2f;
    public LayerMask groundMask;
    public bool isGrounded, isCrouching, isSprinting;
    Vector3 velocity;


    // Update is called once per frame
    void Update()
    {
        //Falling
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
        if(isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        //Jumping
        if(Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        //Moving
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        Vector3 move = transform.right * x + transform.forward * z;

        //Sprinting
        if (Input.GetKeyDown(KeyCode.LeftShift) && !isCrouching)
        {
            isSprinting = true;
            speed *= 1.5f;
        }
        if (Input.GetKeyUp(KeyCode.LeftShift) && !isCrouching)
        {
            isSprinting = false;
            speed = 12;
        }

        //Crouching
        if (Input.GetKeyDown(KeyCode.C) && !isSprinting)
        {
            speed *= .5f;
            isCrouching = true;
            transform.localScale = new Vector3(1, .5f, 1);
        }
        if (Input.GetKeyUp(KeyCode.C) && !isSprinting)
        {
            speed = 12;
            isCrouching = false;
            transform.localScale = new Vector3(1, 1, 1);
        }

        //Sliding
        if (Input.GetKeyDown(KeyCode.C) && isSprinting)
        {
            speed *= 2f;
            isCrouching = true;
            isSprinting = true;
            transform.localScale = new Vector3(1, .25f, 1);
        }
        if (Input.GetKeyUp(KeyCode.C) && isSprinting)
        {
            speed = 12;
            isCrouching = false;
            isSprinting = false;
            transform.localScale = new Vector3(1, 1, 1);
        }
        if (isSprinting && isCrouching)
            speed *= 0.99f;

        //Applying Movement
        controller.Move(move * speed * Time.deltaTime);
        controller.Move(velocity * Time.deltaTime);
        velocity.y += gravity * Time.deltaTime;


        //Interaction, probably shouldn't be here
        Ray ray = cam.ScreenPointToRay(screenMid.position);
        if (Physics.Raycast(ray, out RaycastHit hit, 100))
        {
            Pickup pickupable = hit.collider.GetComponent<Pickup>();
            if (pickupable != null)
            {
                focusInstant = pickupable;
                focusInstant.OnFocused(transform);
            }
            PuzzleComponent puzzleComponent = hit.collider.GetComponent<PuzzleComponent>();
            if (puzzleComponent != null)
            {
                focusInstantB = puzzleComponent;
                focusInstantB.OnFocused(transform);
            }
            Interactable interactable = hit.collider.GetComponent<Interactable>();
            if (Input.GetKeyDown(KeyCode.F) && interactable != null)
            {
                focus = interactable;
                target = focus.transform;
                focus.OnFocused(transform);
            }
        } else if (focus != null)
        {
            target = null;
            focus.OnDeFocused();
            focus = null;
        }  
    }
}
