﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EquipmentSlotController : MonoBehaviour
{

    public Equipable equipable;

    private void Start()
    {
        UpdateInfoEquipable();
    }

    public void UpdateInfoEquipable()
    {
        Text displayText = transform.Find("Text").GetComponent<Text>();
        Image displayImage = transform.Find("Image").GetComponent<Image>();

        if (equipable)
        {
            displayText.text = equipable.equipableName;
            displayImage.sprite = equipable.equipableIcon;
            displayImage.color = Color.white;
        }
        else
        {
            displayText.text = "";
            displayImage.sprite = null;
            //displayImage.color = Color.clear; //das teil hier macht Fehlermeldunge, wir brauchen es aber nicht
        }
    }
}