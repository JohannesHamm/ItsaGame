﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "new Equipable", menuName = "Equipable")]
public class Equipable : ScriptableObject
{
    public enum EquipableType
    {
        Helmet,
        Chestplate,
        Legs,
        Boots,
        WeaponMelee,
        WeaponRanged,
    }

    public string equipableName;
    public Sprite equipableIcon;
    public EquipableType equipableType;

    public virtual void EquipableUse()
    {

    }

    public virtual void OnEquipped()
    {
        switch (equipableType)
        {
            case EquipableType.Helmet:

                break;
            case EquipableType.Chestplate:

                break;
            case EquipableType.Legs:

                break;
            case EquipableType.Boots:

                break;
            case EquipableType.WeaponMelee:

                break;
            case EquipableType.WeaponRanged:

                break;
        }
    }
}
