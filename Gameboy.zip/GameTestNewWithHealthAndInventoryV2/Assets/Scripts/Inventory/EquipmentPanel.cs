﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquipmentPanel : MonoBehaviour
{
    public GameObject player;
    public GameObject inventoryPanel;
    public static EquipmentPanel instance;

    public List<Equipable> list = new List<Equipable>();

    void updatePanelSlots()
    {
        int index = 0;
        foreach (Transform child in inventoryPanel.transform)
        {
            EquipmentSlotController slot = child.GetComponent<EquipmentSlotController>();

            if (index < list.Count)
            {
                slot.equipable = list[index];
            }
            else
            {
                slot.equipable = null;
            }

            slot.UpdateInfoEquipable();
            index++;
        }
    }

    void Start()
    {
        instance = this;
        updatePanelSlots();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
