﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magic : Combat
{
    public GameObject projectile;

    void Update()
    {
        if (nextAttackTime <= 0)
        {
            onCooldown = false;
            if (Input.GetMouseButtonDown(0) && !isEnemy)
            {
                Attack();
            }
        }
        else
        {
            nextAttackTime -= Time.deltaTime;
        }
    }

    public override void Attack()
    {
        if (!isEnemy)
            Instantiate(projectile, attackPoint.position, Quaternion.Euler(attackPoint.rotation.eulerAngles.x, transform.rotation.eulerAngles.y - 90, 0));
        else
            Instantiate(projectile, attackPoint.position, Quaternion.Euler(attackPoint.rotation.eulerAngles.x, attackPoint.rotation.eulerAngles.y, 0));
        onCooldown = true;
        nextAttackTime = attackRate;
    }
}
